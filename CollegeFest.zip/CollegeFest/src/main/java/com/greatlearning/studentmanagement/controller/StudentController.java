package com.greatlearning.studentmanagement.controller;

//import org.springframework.stereotype.Controller;

//@Controller
//public class StudentController {

//}
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.greatlearning.studentmanagement.entity.Student;
import com.greatlearning.studentmanagement.service.StudentService;

@Controller
@RequestMapping("/student")
public class StudentController {

	// For the bean to create object of studentInterface
	@Autowired
	private StudentService studentService;

	// To direct the request for adding new student to the student add form
	@RequestMapping("/addform")
	public String showForm(Model model) {
		Student student = new Student();
		model.addAttribute("mode", "Add");
		model.addAttribute("student", student);
		return "student-form";
	}

	// To direct the request for listing all students in a page with list of all
	// students through JSP page
	@RequestMapping("/list")
	public String showStudents(Model model) {
		List<Student> students = studentService.findAll();
		model.addAttribute("students", students);
		System.out.println(students);
		return "student-list";
	}

	// Post Request for saving(when ID is 0) or updating(when ID is not NULL) the
	// student details.
	// On the save Request the parameters are sent through JSP form will be received
	// here and take care
	@PostMapping("/save")
	public String saveStudent(@RequestParam(name = "studentId") long studentId, @RequestParam(name = "firstName") String firstName,
			@RequestParam(name = "lastName") String lastName,
			@RequestParam(name = "Course") String course,
			@RequestParam(name = "Country") String country) {
		System.out.println("inside save save" + studentId + " " + firstName);
		Student student = null;

		// checking if its for add new student
		if (studentId == 0) {
			student = new Student(firstName, lastName, course, country);
			System.out.println(student);
			// if not its a request for Update
		} else {
			student = studentService.findById(studentId);
			student.setFirstName(firstName);
			student.setLastName(lastName);
			student.setCourse(course);
			student.setCountry(country);
		}
		System.out.println(student);
		studentService.save(student);
		return "redirect:list";
	}

	// Delete the student object
	@RequestMapping("/removeStudent")
	public String removeStudent(@RequestParam(name = "studentId") long studentId) {
		System.out.println("studentId is" + studentId);
		studentService.delete(studentId);
		return "redirect:list";
	}

	// For all the update request, pass the data using model attribute to the jsp
	// student add/update form
	@RequestMapping("/updateStudent")
	public String updateStudent(@RequestParam(name = "studentId") long studentId, Model model) {
		Student student = studentService.findById(studentId);
		model.addAttribute("mode", "Update");
		model.addAttribute("student", student);

		return "student-form";
	}

}
